SSH 远端 — windows x64

双击 SSH-Remote.lnk（终端图标）或 START-REMOTE.cmd。首次启动自动创建桌面上的 SSH Remote 图标。Windows 10/11 x64。

已内置官方 Node.js v22.23.3，不用安装 Node 或 npm，也不需要管理员权限安装。完整解压后再启动，不要在压缩包内直接运行；保留整个解压目录，桌面图标会引用这里。

启动后保持窗口开启，把完整私密连接块交给可信 AI。两端都更新并核对协议 2。远端继承启动账户权限；管理员权限需求请使用你已获授权的管理员终端启动。data/ 首次运行时生成，内含私钥，不要上传。

这是近远端运行包，完整 MCP 工程与提示词在 source.zip。此包为构建产物，不冒称原始源码。运行时来自 nodejs.org，下载文件与官方 SHASUMS256.txt 校验一致。Windows 与 Linux 分开下载。
