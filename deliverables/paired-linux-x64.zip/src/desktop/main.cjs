"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// src/paired-store.cjs
var require_paired_store = __commonJS({
  "src/paired-store.cjs"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var crypto2 = require("node:crypto");
    var protectedDirectories = /* @__PURE__ */ new Set();
    function privateDirectory2(dir) {
      fs2.mkdirSync(dir, { recursive: true, mode: 448 });
      if (fs2.lstatSync(dir).isSymbolicLink()) throw new Error("State directory must not be a symlink");
      fs2.chmodSync(dir, 448);
      if (process.platform === "win32" && !protectedDirectories.has(path2.resolve(dir))) {
        const { spawnSync } = require("node:child_process");
        const sid = spawnSync("whoami.exe", ["/user", "/fo", "csv", "/nh"], { encoding: "utf8", windowsHide: true });
        const match = sid.stdout?.match(/S-1-\d+(?:-\d+)+/);
        if (sid.status !== 0 || !match) throw new Error("Cannot determine state owner SID");
        const result = spawnSync("icacls.exe", [path2.resolve(dir), "/inheritance:r", "/grant:r", "*" + match[0] + ":(OI)(CI)F", "*S-1-5-18:(OI)(CI)F"], { encoding: "utf8", windowsHide: true });
        if (result.status !== 0) throw new Error("Cannot protect application state permissions");
        protectedDirectories.add(path2.resolve(dir));
      }
    }
    function save2(file, data) {
      privateDirectory2(path2.dirname(file));
      if (fs2.existsSync(file) && fs2.lstatSync(file).isSymbolicLink()) throw new Error("State file must not be a symlink");
      const temp = file + "." + crypto2.randomBytes(8).toString("hex") + ".tmp";
      try {
        fs2.writeFileSync(temp, JSON.stringify(data, null, 2) + "\n", { flag: "wx", mode: 384 });
        fs2.renameSync(temp, file);
      } finally {
        if (fs2.existsSync(temp)) fs2.unlinkSync(temp);
      }
    }
    function load2(file, fallback) {
      if (!fs2.existsSync(file)) return fallback;
      if (fs2.lstatSync(file).isSymbolicLink()) throw new Error("State file must not be a symlink");
      return JSON.parse(fs2.readFileSync(file, "utf8"));
    }
    function validateInfo(info) {
      if (!info || info.version !== 1 || !["linux", "win10"].includes(info.target) || info.broker !== "wss://broker.emqx.io:8084/mqtt" || info.user !== "relay" || !/^[a-f0-9]{32}$/.test(info.session) || !/^[a-f0-9]{64}$/.test(info.secret)) throw new Error("Invalid paired host");
      const parts = (info.hostPublicKey || "").split(" ");
      if (parts.length !== 2 || parts[0] !== "ssh-ed25519") throw new Error("Invalid host key");
      const fp = "SHA256:" + crypto2.createHash("sha256").update(Buffer.from(parts[1], "base64")).digest("base64").replace(/=+$/, "");
      if (fp !== info.fingerprint) throw new Error("Host fingerprint mismatch");
      if (typeof info.clientPrivateKey !== "string" || !info.clientPrivateKey.startsWith("-----BEGIN OPENSSH PRIVATE KEY-----")) throw new Error("Invalid client key");
      return info;
    }
    module2.exports = { privateDirectory: privateDirectory2, save: save2, load: load2, validateInfo };
  }
});

// src/diagnostics.cjs
var require_diagnostics = __commonJS({
  "src/diagnostics.cjs"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    function createTraceWriter2(directory, role2) {
      const file = path2.join(directory, role2 + "-events.jsonl");
      const limit = 2 * 1024 * 1024;
      let failed = false;
      return function record(entry) {
        if (failed) return;
        try {
          if (fs2.existsSync(file) && fs2.lstatSync(file).isSymbolicLink())
            throw new Error("Diagnostic path is a symlink");
          if (fs2.existsSync(file) && fs2.statSync(file).size >= limit) {
            for (let i = 2; i >= 1; i--) {
              const from = file + "." + i, to = file + "." + (i + 1);
              if (fs2.existsSync(from)) fs2.renameSync(from, to);
            }
            fs2.renameSync(file, file + ".1");
          }
          fs2.appendFileSync(
            file,
            JSON.stringify({ time: (/* @__PURE__ */ new Date()).toISOString(), role: role2, ...entry }) + "\n",
            { mode: 384 }
          );
        } catch (error) {
          failed = true;
          console.error("Diagnostic log unavailable: " + error.message);
        }
      };
    }
    module2.exports = { createTraceWriter: createTraceWriter2 };
  }
});

// src/desktop/main.cjs
var { app, BrowserWindow, Tray, Menu, ipcMain, shell, nativeImage } = require("electron");
var path = require("node:path");
var fs = require("node:fs");
var os = require("node:os");
var { fork } = require("node:child_process");
var crypto = require("node:crypto");
var { save, load, privateDirectory } = require_paired_store();
var { createTraceWriter } = require_diagnostics();
var argv = process.argv.slice(1);
var at = argv.indexOf("--role");
var role = at < 0 ? "near" : argv[at + 1];
if (!["near", "far"].includes(role)) throw new Error("Invalid endpoint role");
var si = argv.indexOf("--state-dir");
var root = path.resolve(si < 0 ? path.join(os.homedir(), ".ssh-relay-paired", role) : argv[si + 1]);
privateDirectory(root);
var desktopLog = createTraceWriter(root, "desktop-" + role);
var errorMetadata = (error) => ({ name: String(error?.name || "Error").slice(0, 60), code: String(error?.code || "desktop_error").slice(0, 60) });
process.on("uncaughtException", (error) => {
  desktopLog({ event: "desktop_uncaught", ...errorMetadata(error) });
  app.exit(1);
});
process.on("unhandledRejection", (error) => {
  desktopLog({ event: "desktop_rejection", ...errorMetadata(error) });
  app.exit(1);
});
desktopLog({ event: "desktop_started", pid: process.pid });
app.setPath("userData", path.join(root, "desktop"));
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  let loginState = function() {
    if (process.platform === "win32" || process.platform === "darwin")
      return app.getLoginItemSettings({ path: process.execPath, args: startupArgs }).openAtLogin;
    if (process.platform === "linux") {
      if (!fs.existsSync(desktopFile)) return false;
      const text = fs.readFileSync(desktopFile, "utf8");
      return text.includes("X-SSH-Relay-Owned=true") && text.includes("Exec=" + launchCommand() + "\n") && !text.includes("Hidden=true");
    }
    return false;
  }, setLogin = function(enabled) {
    if (typeof enabled !== "boolean") throw new Error("Invalid startup setting");
    if (process.platform === "win32" || process.platform === "darwin")
      app.setLoginItemSettings({ openAtLogin: enabled, path: process.execPath, args: startupArgs, name: startupId });
    else if (process.platform === "linux") {
      if (enabled) {
        fs.mkdirSync(path.dirname(desktopFile), { recursive: true, mode: 448 });
        if (fs.existsSync(desktopFile) && !fs.readFileSync(desktopFile, "utf8").includes("X-SSH-Relay-Owned=true")) throw new Error("Startup name is occupied");
        fs.writeFileSync(desktopFile, "[Desktop Entry]\nType=Application\nName=" + title + "\nExec=" + launchCommand() + "\nTerminal=false\nX-SSH-Relay-Owned=true\n", { mode: 384 });
      } else if (fs.existsSync(desktopFile)) {
        if (!fs.readFileSync(desktopFile, "utf8").includes("X-SSH-Relay-Owned=true")) throw new Error("Startup entry is not owned by this app");
        fs.unlinkSync(desktopFile);
      }
    } else throw new Error("Startup is unsupported on this platform");
    if (loginState() !== enabled) throw new Error("Operating system did not confirm startup registration");
    save(path.join(root, "desktop-settings.json"), { autostart: enabled });
    desktopLog({ event: "autostart_changed", enabled });
    return enabled;
  }, snapshot = function() {
    return { ...state, pairing: pair, autostart: loginState(), startupMode: "\u7528\u6237\u767B\u5F55\u540E\u9759\u9ED8\u542F\u52A8", role };
  }, update = function() {
    if (win && !win.isDestroyed()) win.webContents.send("status", snapshot());
    if (tray) {
      tray.setToolTip(title + " \xB7 " + state.phase);
      tray.setContextMenu(Menu.buildFromTemplate([
        { label: "\u6253\u5F00\u63A7\u5236\u9762\u677F", click: show },
        { label: "\u72B6\u6001\uFF1A" + state.phase, enabled: false },
        ...role === "near" ? [{ label: "\u81EA\u52A8\u8FDE\u63A5\u5DF2\u914D\u5BF9\u7535\u8111", type: "checkbox", checked: !!state.autoConnect, click: (item) => agent?.send({ action: item.checked ? "connect" : "pause" }) }] : [],
        { label: "\u767B\u5F55\u540E\u81EA\u542F\u52A8", type: "checkbox", checked: loginState(), click: (item) => {
          try {
            setLogin(item.checked);
            update();
          } catch {
            show();
            win.webContents.send("ui-error", "\u81EA\u542F\u52A8\u6CE8\u518C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7CFB\u7EDF\u6743\u9650");
          }
        } },
        { label: "\u67E5\u770B\u8BCA\u65AD\u76EE\u5F55", click: () => shell.openPath(root) },
        { type: "separator" },
        { label: "\u9000\u51FA\u5E76\u505C\u6B62\u8FDE\u63A5", click: () => {
          quitting = true;
          app.quit();
        } }
      ]));
    }
  }, show = function(visible = true) {
    if (!win || win.isDestroyed()) {
      win = new BrowserWindow({
        width: 880,
        height: 720,
        minWidth: 650,
        minHeight: 550,
        title,
        icon: path.join(appRoot, "assets", "paired.png"),
        show: false,
        webPreferences: { preload: path.join(__dirname, "preload.cjs"), nodeIntegration: false, contextIsolation: true, sandbox: true }
      });
      win.removeMenu();
      win.loadFile(path.join(__dirname, "index.html"));
      win.once("ready-to-show", () => {
        if (visible) win.show();
        update();
      });
      win.on("close", (event) => {
        if (!quitting) {
          event.preventDefault();
          win.hide();
        }
      });
      win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
      win.webContents.on("will-navigate", (event) => event.preventDefault());
    } else {
      if (visible) {
        win.show();
        win.focus();
      }
      update();
    }
  }, startAgent = function() {
    if (quitting) return;
    agent = fork(path.join(appRoot, "src", "paired-agent.cjs"), ["--role", role, "--state-dir", root], {
      env: { ...process.env, ELECTRON_RUN_AS_NODE: "1" },
      execPath: process.execPath,
      silent: true,
      windowsHide: true
    });
    agent.stdout.resume();
    agent.stderr.resume();
    desktopLog({ event: "agent_started", pid: agent.pid });
    agent.on("message", (message) => {
      if (message.type === "status") {
        state = message.status;
        if (state.phase === "connected" || state.phase === "listening") {
          if (!agentStableTimer) {
            agentStableTimer = setTimeout(() => {
              restartAttempt = 0;
              agentStableTimer = null;
            }, 6e4);
            agentStableTimer.unref();
          }
        } else {
          clearTimeout(agentStableTimer);
          agentStableTimer = null;
        }
      }
      if (message.type === "pairing") pair = message.pairing;
      update();
    });
    agent.on("error", (error) => desktopLog({ event: "agent_start_error", ...errorMetadata(error) }));
    agent.on("exit", (code, signal) => {
      desktopLog({ event: "agent_exit", code, signal });
      clearTimeout(agentStableTimer);
      agentStableTimer = null;
      agent = null;
      if (quitting) return;
      state = { ...state, connected: false, phase: "manager_restarting" };
      update();
      const wait = Math.min(6e4, 2e3 * 2 ** Math.min(restartAttempt++, 5));
      restartTimer = setTimeout(startAgent, wait);
    });
  };
  let win, tray, agent, quitting = false, state = { role, phase: "starting", targets: [] }, pair = null;
  let restartTimer, restartAttempt = 0;
  let agentStableTimer;
  const title = role === "near" ? "SSH Relay \xB7 \u8FD1\u7AEF" : "SSH Relay \xB7 \u8FDC\u7AEF";
  const appRoot = path.resolve(__dirname, "../..");
  const application = path.join(appRoot, "desktop-package");
  const startupArgs = [application, "--role", role, "--state-dir", root, "--background"];
  const startupId = "SSHRelayPaired-" + role + "-" + crypto.createHash("sha256").update(process.platform === "win32" ? root.toLowerCase() : root).digest("hex").slice(0, 12);
  const desktopFile = path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), ".config"), "autostart", startupId + ".desktop");
  const q = (arg) => {
    if (/[\n\r\0%]/.test(arg)) throw new Error("Unsupported startup path");
    return '"' + arg.replace(/[\\"`$]/g, "\\$&") + '"';
  };
  const launchCommand = () => [process.execPath, ...startupArgs].map(q).join(" ");
  ipcMain.handle("snapshot", (event) => {
    if (event.sender !== win?.webContents) throw new Error("Invalid sender");
    return snapshot();
  });
  ipcMain.handle("action", (event, message) => {
    if (event.sender !== win?.webContents || !message || typeof message !== "object") throw new Error("Invalid sender");
    if (message.action === "startup") {
      const result = setLogin(message.enabled);
      update();
      return result;
    }
    if (message.action === "logs") return shell.openPath(root);
    if (!["pair", "connect", "pause", "forget", "revoke-all"].includes(message.action)) throw new Error("Unknown action");
    if (typeof message.code === "string" && message.code.length > 100) throw new Error("Invalid code");
    if (message.target && !/^[a-f0-9]{32}$/.test(message.target)) throw new Error("Invalid target");
    if (!agent?.connected) throw new Error("Connection service is restarting");
    agent.send(message);
    return true;
  });
  app.on("second-instance", (_event, commandLine) => {
    if (!commandLine.includes("--background")) show();
  });
  app.on("window-all-closed", () => {
  });
  app.on("before-quit", () => {
    quitting = true;
    clearTimeout(restartTimer);
    clearTimeout(agentStableTimer);
    agent?.send({ action: "quit" });
    setTimeout(() => agent?.kill(), 2500).unref();
    tray?.destroy();
  });
  app.whenReady().then(() => {
    desktopLog({ event: "desktop_ready" });
    privateDirectory(root);
    tray = new Tray(nativeImage.createFromPath(path.join(appRoot, "assets", "paired.png")));
    tray.on("double-click", show);
    tray.on("click", show);
    startAgent();
    update();
    show(!argv.includes("--background"));
  });
}
