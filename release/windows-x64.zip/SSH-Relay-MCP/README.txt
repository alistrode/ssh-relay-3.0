版本分类 3.0：稳定公网中继＋MCP。
远端：原有 START-REMOTE 启动入口。近端：使用包内连接导入工具，显式指定包内 runtime/node（Windows 为 node.exe）。
MCP：Linux 运行 ./mcp，Windows 使用 MCP.cmd，并按 docs/MCP-MANUAL.md 传入已验证的连接报告。
已内置 Node、完整 MCP 实现与生产依赖，无须 npm install。配对 GUI 预览版不属于此运行包。
Windows 本次只做静态核对，未做实机启动验收。
