@echo off
setlocal DisableDelayedExpansion
"%~dp0runtime\node.exe" "%~dp0src\mcp.cjs" %*
